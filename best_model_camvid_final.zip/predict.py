import torch
import cv2
import numpy as np
import matplotlib.pyplot as plt
import segmentation_models_pytorch as smp
import os

# ================= 配置区域 =================
#MODEL_PATH = './best_model_mixed.pth'  # 确保你加载的是混合训练的模型
MODEL_PATH ='./best_model_camvid_final.pth'   # 确保跑完训练后有这个文件
#IMAGE_PATH = './Mytest.jpg'  # 你的测试图片路径
#IMAGE_PATH = './dataset/cityscapes/train/train1098.png'
IMAGE_PATH = './dataset/camvid/train/0016E5_04350.png' #白天数据
#IMAGE_PATH = './dataset/camvid/train/0016E5_04950.png'
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
INPUT_HEIGHT = 384
INPUT_WIDTH = 480

# 颜色定义: 0=背景, 1=路(绿), 2=人(黄), 3=车(红)
CLASS_COLORS = {
    0: (0, 0, 0),  # 背景透明
    1: (0, 255, 0),  # 路
    2: (255, 255, 0),  # 人
    3: (255, 0, 0)  # 车
}


def colorize_mask(class_map):
    colored = np.zeros((class_map.shape[0], class_map.shape[1], 3), dtype=np.uint8)
    for id, color in CLASS_COLORS.items():
        colored[class_map == id] = color
    return colored


if __name__ == '__main__':
    os.environ['HF_HUB_OFFLINE'] = '1'
    print(f"正在加载模型: {MODEL_PATH} ...")

    try:
        # === 修改后的代码 ===
        # 智能判断：如果当前电脑有显卡，保持默认(None)；如果是轻薄本没显卡，强制映射到 CPU
        map_loc = None if torch.cuda.is_available() else 'cpu'
        model = torch.load(MODEL_PATH, map_location=map_loc, weights_only=False)
    except FileNotFoundError:
        print("❌ 找不到模型文件！")  # 👈 这里缩进了，就对了
    model.to(DEVICE)
    model.eval()

    # 读取图片
    image = cv2.imread(IMAGE_PATH)
    if image is None:
        print(f"❌ 找不到图片: {IMAGE_PATH}")
        exit()
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    img_resized = cv2.resize(image, (INPUT_WIDTH, INPUT_HEIGHT))

    # ================= 关键修复：预处理 =================
    # 必须和训练时完全一致！否则模型就是“瞎”的
    print("正在进行预处理...")
    prep_fn = smp.encoders.get_preprocessing_fn('mobilenet_v2', 'imagenet')

    # 1. 归一化 (0-255 -> 小数)
    img_prep = prep_fn(img_resized)

    # 2. 维度转换 (H,W,C) -> (C,H,W)
    img_prep = img_prep.transpose(2, 0, 1).astype('float32')

    # 3. 转 Tensor
    tensor = torch.from_numpy(img_prep).unsqueeze(0).to(DEVICE)
    # ===================================================

    print("正在推理...")
    with torch.no_grad():
        output = model(tensor)
        # 找到概率最大的类别索引 (0, 1, 2, 3)
        pred = np.argmax(output.squeeze().cpu().numpy(), axis=0)

    # === 调试信息 (关键！) ===
    unique_classes = np.unique(pred)
    print(f"🔍 检测到的类别 ID: {unique_classes}")
    if len(unique_classes) == 1 and unique_classes[0] == 0:
        print("⚠️ 警告：模型把整张图都预测成了背景(0)！")
        print("可能原因：1. 训练轮数太少(Loss太高)  2. 标签映射错误")
    else:
        print(f"✅ 成功检测到目标！包含类别: {unique_classes}")

    # 绘图
    colored = colorize_mask(pred)
    # 混合: 背景(0)不混合，其他类别(>0)混合
    mask_bool = (pred > 0)[:, :, None]
    blended = np.where(mask_bool, img_resized * 0.6 + colored * 0.4, img_resized)

    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1);
    plt.title("Input");
    plt.imshow(img_resized);
    plt.axis('off')
    plt.subplot(1, 2, 2);
    plt.title("Result");
    plt.imshow(blended.astype(np.uint8));
    plt.axis('off')
    plt.show()